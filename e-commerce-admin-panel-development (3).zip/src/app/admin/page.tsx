"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Layers, FolderOpen, Package, ImageIcon, ShoppingBag,
  Tag, Shirt, Trophy, ArrowUpRight, Plus, TrendingUp,
} from "lucide-react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    collections: 0, categories: 0, items: 0, slides: 0,
    orders: 0, revenue: 0, offers: 0, dresses: 0, winners: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchStats(); }, []);

  async function fetchStats() {
    try {
      const [collections, categories, items, slides, orders, offers, dresses, winners] = await Promise.all([
        fetch("/api/collections").then((r) => r.json()),
        fetch("/api/categories").then((r) => r.json()),
        fetch("/api/items").then((r) => r.json()),
        fetch("/api/slides").then((r) => r.json()),
        fetch("/api/orders").then((r) => r.json()),
        fetch("/api/offers").then((r) => r.json()),
        fetch("/api/dresses").then((r) => r.json()),
        fetch("/api/winners").then((r) => r.json()),
      ]);
      const revenue = orders.reduce((sum: number, o: any) => sum + parseFloat(o.totalAmount || 0), 0);
      setStats({
        collections: collections.length || 0, categories: categories.length || 0,
        items: items.length || 0, slides: slides.length || 0, orders: orders.length || 0,
        revenue, offers: offers.length || 0, dresses: dresses.length || 0, winners: winners.length || 0,
      });
    } catch (e) {}
    setLoading(false);
  }

  const quickLinks = [
    { href: "/admin/items", label: "Add Product", icon: Package },
    { href: "/admin/offers", label: "New Offer", icon: Tag },
    { href: "/admin/dresses", label: "Onam Dress", icon: Shirt },
    { href: "/admin/slides", label: "New Slide", icon: ImageIcon },
  ];

  const tiles = [
    { label: "Products", value: stats.items, icon: Package, tone: "bg-forest-600", link: "/admin/items" },
    { label: "Onam Dresses", value: stats.dresses, icon: Shirt, tone: "bg-rose-600", link: "/admin/dresses" },
    { label: "Today's Offers", value: stats.offers, icon: Tag, tone: "bg-amber-600", link: "/admin/offers" },
    { label: "Categories", value: stats.categories, icon: FolderOpen, tone: "bg-sky-600", link: "/admin/categories" },
    { label: "Collections", value: stats.collections, icon: Layers, tone: "bg-violet-600", link: "/admin/collections" },
    { label: "Hero Slides", value: stats.slides, icon: ImageIcon, tone: "bg-teal-600", link: "/admin/slides" },
    { label: "Lucky Winners", value: stats.winners, icon: Trophy, tone: "bg-yellow-600", link: "/admin/winners" },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-[0.22em] text-forest-700/70 mb-2">
            Control centre · {new Date().toLocaleDateString("en-GB", { weekday: "long" })}
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-semibold tracking-tight text-forest-900">
            Good day, <span className="italic text-forest-600">Admin.</span>
          </h1>
          <p className="text-stone-600 mt-2 max-w-xl">
            Everything that appears on the website — products, offers, slides, dresses, winners — is controlled from here. Changes publish to the live site instantly.
          </p>
        </div>
        <a href="/" target="_blank" className="inline-flex items-center gap-2 self-start px-5 py-3 rounded-full bg-forest-900 text-white text-sm font-medium hover:bg-forest-700 transition shadow-lg shadow-forest-900/20">
          Visit live site <ArrowUpRight className="w-4 h-4" />
        </a>
      </header>

      {/* Hero revenue card */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-forest-900 via-forest-700 to-forest-600 p-8 md:p-10 text-white animate-slide-up">
        <div className="absolute inset-0 grain opacity-10 pointer-events-none" />
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-amber-400/20 blur-3xl" />
        <div className="absolute -left-16 -bottom-16 w-64 h-64 rounded-full bg-emerald-300/10 blur-3xl" />

        <div className="relative grid md:grid-cols-3 gap-8 items-end">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 text-emerald-200 text-xs font-mono uppercase tracking-widest mb-3">
              <TrendingUp className="w-3.5 h-3.5" /> Total revenue
            </div>
            <div className="font-display text-6xl md:text-7xl font-semibold tracking-tight leading-none">
              £{stats.revenue.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="mt-3 text-emerald-100/80 text-sm">
              Across {stats.orders} {stats.orders === 1 ? "order" : "orders"} · Cash on delivery enabled
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="text-[11px] uppercase tracking-widest text-emerald-200/80 font-mono">Orders today</div>
              <div className="font-display text-3xl font-semibold mt-1">{stats.orders}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="text-[11px] uppercase tracking-widest text-emerald-200/80 font-mono">Avg. basket</div>
              <div className="font-display text-3xl font-semibold mt-1">
                £{stats.orders ? (stats.revenue / stats.orders).toFixed(2) : "0.00"}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick actions */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-xl font-semibold text-forest-900">Quick actions</h2>
          <span className="text-xs text-stone-500 font-mono">4 shortcuts</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {quickLinks.map((q) => (
            <Link key={q.href} href={q.href} className="card-hover group bg-white rounded-2xl p-5 border border-stone-200 flex items-center justify-between">
              <div>
                <div className="text-[11px] font-mono uppercase tracking-widest text-stone-400 mb-1">New</div>
                <div className="font-display text-lg font-semibold text-forest-900">{q.label}</div>
              </div>
              <div className="w-10 h-10 rounded-full bg-forest-50 text-forest-700 flex items-center justify-center group-hover:bg-forest-600 group-hover:text-white transition">
                <Plus className="w-4 h-4" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Catalog tiles */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-xl font-semibold text-forest-900">Catalog at a glance</h2>
          <span className="text-xs text-stone-500 font-mono">Click to manage</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {tiles.map((t) => (
            <Link key={t.label} href={t.link} className="card-hover group relative overflow-hidden bg-white rounded-2xl p-5 border border-stone-200">
              <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full ${t.tone} opacity-10 group-hover:opacity-20 group-hover:scale-125 transition-all duration-500`} />
              <div className="relative flex items-start justify-between">
                <div className={`w-10 h-10 rounded-lg ${t.tone} text-white flex items-center justify-center shadow-sm`}>
                  <t.icon className="w-4 h-4" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-stone-300 group-hover:text-forest-700 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition" />
              </div>
              <div className="relative mt-6">
                <div className="font-display text-4xl font-semibold text-forest-900 leading-none">{loading ? "—" : t.value}</div>
                <div className="text-sm text-stone-600 mt-2">{t.label}</div>
              </div>
            </Link>
          ))}
          <Link href="/admin/orders" className="card-hover group relative overflow-hidden bg-forest-900 text-white rounded-2xl p-5 border border-forest-900">
            <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-amber-400 opacity-20 group-hover:scale-125 transition-all duration-500" />
            <div className="relative flex items-start justify-between">
              <div className="w-10 h-10 rounded-lg bg-amber-400 text-forest-900 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-white/40 group-hover:text-amber-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition" />
            </div>
            <div className="relative mt-6">
              <div className="font-display text-4xl font-semibold leading-none">{loading ? "—" : stats.orders}</div>
              <div className="text-sm text-emerald-200 mt-2">Total orders</div>
            </div>
          </Link>
        </div>
      </section>

      {/* Workflow note */}
      <section className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8">
        <h2 className="font-display text-xl font-semibold text-forest-900 mb-4">How it works</h2>
        <ol className="grid md:grid-cols-4 gap-6 text-sm">
          {[
            { n: "01", t: "Create in admin", d: "Add a product, slide, offer, or dress using the forms on the left." },
            { n: "02", t: "Upload media", d: "Attach photos — they're stored and served through a dedicated file route." },
            { n: "03", t: "Publish instantly", d: "Save and the live website picks up the change on the next visit. No deploy." },
            { n: "04", t: "Receive orders", d: "Customers pay COD — the order lands here and on your WhatsApp." },
          ].map((s) => (
            <li key={s.n} className="relative">
              <div className="font-mono text-xs text-amber-600 tracking-widest mb-2">{s.n}</div>
              <div className="font-display text-base font-semibold text-forest-900 mb-1">{s.t}</div>
              <div className="text-stone-600 leading-relaxed">{s.d}</div>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
