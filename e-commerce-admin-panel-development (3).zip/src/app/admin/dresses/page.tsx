"use client";

import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, ImageIcon, X } from "lucide-react";

export default function DressesPage() {
  const [dressesList, setDressesList] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: "", type: "ladies", description: "", price: "", compareAtPrice: "", images: [] as string[], sizes: [] as string[], colors: [] as string[], stock: 0, sortOrder: 0, isActive: true });
  const [uploading, setUploading] = useState(false);

  useEffect(() => { fetchDresses(); }, []);

  async function fetchDresses() {
    const res = await fetch("/api/dresses");
    const data = await res.json();
    setDressesList(data);
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "uploads/dresses");
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) setForm((f) => ({ ...f, images: [...f.images, data.url] }));
    setUploading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = { ...form, price: form.price, compareAtPrice: form.compareAtPrice || null, images: form.images.length > 0 ? form.images : null };
    if (editing) {
      await fetch("/api/dresses", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...payload, id: editing.id }) });
    } else {
      await fetch("/api/dresses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    }
    setShowForm(false); setEditing(null);
    setForm({ name: "", type: "ladies", description: "", price: "", compareAtPrice: "", images: [], sizes: [], colors: [], stock: 0, sortOrder: 0, isActive: true });
    fetchDresses();
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this dress?")) return;
    await fetch(`/api/dresses?id=${id}`, { method: "DELETE" });
    fetchDresses();
  }

  function openEdit(d: any) {
    setEditing(d);
    setForm({ name: d.name, type: d.type, description: d.description || "", price: String(d.price), compareAtPrice: d.compareAtPrice ? String(d.compareAtPrice) : "", images: d.images || [], sizes: d.sizes || [], colors: d.colors || [], stock: d.stock || 0, sortOrder: d.sortOrder || 0, isActive: d.isActive });
    setShowForm(true);
  }

  function toggleSize(size: string) {
    setForm((f) => ({ ...f, sizes: f.sizes.includes(size) ? f.sizes.filter((s) => s !== size) : [...f.sizes, size] }));
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Dress Collections</h1>
        <button onClick={() => { setShowForm(true); setEditing(null); setForm({ name: "", type: "ladies", description: "", price: "", compareAtPrice: "", images: [], sizes: [], colors: [], stock: 0, sortOrder: 0, isActive: true }); }} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          <Plus className="w-4 h-4" /> Add Dress
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 mb-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label className="block text-sm font-medium text-slate-700 mb-1">Name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="ladies">Ladies</option>
                <option value="gents">Gents</option>
                <option value="kids">Kids</option>
                <option value="combo">Combo</option>
              </select>
            </div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1">Price</label><input required type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label className="block text-sm font-medium text-slate-700 mb-1">Compare At Price</label><input type="number" step="0.01" value={form.compareAtPrice} onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1">Stock</label><input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1">Sort Order</label><input type="number" value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" /></div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Sizes</label>
            <div className="flex gap-2 flex-wrap">
              {["XS","S","M","L","XL","2XL","3XL"].map((size) => (
                <button key={size} type="button" onClick={() => toggleSize(size)} className={`px-3 py-1.5 rounded-lg border text-sm ${form.sizes.includes(size) ? "bg-blue-600 text-white border-blue-600" : "border-slate-300 hover:border-slate-400"}`}>{size}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Colors (comma separated)</label>
            <input value={form.colors.join(", ")} onChange={(e) => setForm({ ...form, colors: e.target.value.split(",").map((c) => c.trim()).filter(Boolean) })} placeholder="Red, Blue, Green" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" rows={2} />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Images</label>
            <div className="flex items-center gap-3 flex-wrap">
              <label className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                <ImageIcon className="w-4 h-4" /><span className="text-sm">{uploading ? "Uploading..." : "Add Image"}</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
              {form.images.map((img, i) => (
                <div key={i} className="relative">
                  <img src={img} alt="" className="w-16 h-16 object-cover rounded-lg" />
                  <button type="button" onClick={() => setForm({ ...form, images: form.images.filter((_, idx) => idx !== i) })} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5"><X className="w-3 h-3" /></button>
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} className="w-4 h-4" />
            <label className="text-sm text-slate-700">Active</label>
          </div>
          <div className="flex gap-3">
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">{editing ? "Update" : "Create"}</button>
            <button type="button" onClick={() => setShowForm(false)} className="bg-slate-200 text-slate-700 px-6 py-2 rounded-lg hover:bg-slate-300">Cancel</button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Image</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Type</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Price</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Sizes</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {dressesList.map((d) => (
              <tr key={d.id} className="hover:bg-slate-50">
                <td className="px-6 py-4">{d.images?.[0] ? <img src={d.images[0]} alt="" className="w-12 h-12 object-cover rounded-lg" /> : <div className="w-12 h-12 bg-slate-200 rounded-lg" />}</td>
                <td className="px-6 py-4 font-medium text-slate-900">{d.name}</td>
                <td className="px-6 py-4"><span className="capitalize px-2 py-1 bg-slate-100 rounded-full text-xs">{d.type}</span></td>
                <td className="px-6 py-4 font-medium text-slate-900">£{d.price}</td>
                <td className="px-6 py-4 text-slate-500 text-sm">{d.sizes?.join(", ") || "-"}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(d)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(d.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
