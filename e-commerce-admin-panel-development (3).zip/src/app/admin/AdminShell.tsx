"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import {
  LayoutDashboard, Layers, FolderOpen, Package, ImageIcon,
  ShoppingBag, Settings, Store, Tag, Shirt, Trophy, ExternalLink,
  Menu, X, Search, Bell,
} from "lucide-react";

const navGroups = [
  {
    title: "Overview",
    items: [{ href: "/admin", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    title: "Catalog",
    items: [
      { href: "/admin/collections", label: "Collections", icon: Layers },
      { href: "/admin/categories", label: "Categories", icon: FolderOpen },
      { href: "/admin/items", label: "Products", icon: Package },
      { href: "/admin/dresses", label: "Onam Dresses", icon: Shirt },
      { href: "/admin/offers", label: "Today's Offers", icon: Tag },
    ],
  },
  {
    title: "Content",
    items: [
      { href: "/admin/slides", label: "Hero Slides", icon: ImageIcon },
      { href: "/admin/winners", label: "Lucky Winners", icon: Trophy },
    ],
  },
  {
    title: "Operations",
    items: [
      { href: "/admin/orders", label: "Orders", icon: ShoppingBag },
      { href: "/admin/settings", label: "Settings", icon: Settings },
    ],
  },
];

export default function AdminShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const pathname = usePathname();

  useEffect(() => { setHydrated(true); }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const Sidebar = (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-white/5">
        <Link href="/admin" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-900/30 group-hover:scale-105 transition-transform">
            <span className="font-display text-xl font-bold text-[#0d2f16]">K</span>
          </div>
          <div className="leading-tight">
            <div className="font-display text-[15px] font-semibold tracking-tight text-white">Kerala Super Store</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-emerald-300/70 font-mono mt-0.5">Admin Console</div>
          </div>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-6 overflow-y-auto scrollbar-hide">
        {navGroups.map((group) => (
          <div key={group.title}>
            <div className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-emerald-300/40 font-mono">
              {group.title}
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-[13.5px] transition-colors font-medium ${
                      active
                        ? "bg-white/10 text-white border-l-2 border-amber-400"
                        : "text-emerald-50/70 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <item.icon className={`w-4 h-4 ${active ? "text-amber-300" : "text-emerald-300/60"}`} />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-4 border-t border-white/5 space-y-2">
        <a
          href="/"
          target="_blank"
          className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-[13px] text-white"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span className="flex-1">View live website</span>
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
          </span>
        </a>
      </div>
    </div>
  );

  return (
    <div className="admin-scope flex min-h-screen bg-[#faf7f0] text-slate-900">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-72 bg-[#0d2f16] text-white flex-col fixed h-screen z-40 border-r border-[#0a2411]">
        {Sidebar}
      </aside>

      {/* Mobile sidebar */}
      <div className={`lg:hidden fixed inset-0 z-50 ${open ? "" : "pointer-events-none"}`}>
        <div
          className={`absolute inset-0 bg-black/50 transition-opacity ${open ? "opacity-100" : "opacity-0"}`}
          onClick={() => setOpen(false)}
        />
        <aside
          className={`absolute left-0 top-0 h-full w-72 bg-[#0d2f16] text-white shadow-2xl transition-transform duration-300 ${
            open ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <button
            onClick={() => setOpen(false)}
            className="absolute top-4 right-4 p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 z-10"
          >
            <X className="w-4 h-4" />
          </button>
          {Sidebar}
        </aside>
      </div>

      {/* Main */}
      <main className="flex-1 lg:ml-72 min-h-screen">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-[#faf7f0]/85 backdrop-blur-md border-b border-stone-200/60">
          <div className="flex items-center justify-between px-4 md:px-8 py-3 md:py-4 gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button
                onClick={() => setOpen(true)}
                className="lg:hidden p-2 rounded-lg bg-white border border-stone-200 text-forest-700 hover:bg-stone-50"
              >
                <Menu className="w-4 h-4" />
              </button>
              <div className="hidden md:flex items-center gap-3">
                <Store className="w-4 h-4 text-forest-600" />
                <span className="text-xs font-mono uppercase tracking-widest text-stone-500">KSS · v1.0</span>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-forest-50 text-forest-700 border border-forest-100">
                <span className="live-dot w-1.5 h-1.5 rounded-full bg-forest-600"></span>
                <span className="text-xs font-medium">{hydrated ? "Connected" : "Loading"}</span>
              </div>
              <button className="p-2 rounded-lg bg-white border border-stone-200 hover:bg-stone-50 text-stone-600 hidden md:flex">
                <Search className="w-4 h-4" />
              </button>
              <button className="relative p-2 rounded-lg bg-white border border-stone-200 hover:bg-stone-50 text-stone-600">
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-500 rounded-full"></span>
              </button>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-forest-600 to-forest-900 text-white flex items-center justify-center text-xs font-semibold font-display cursor-pointer" onClick={() => { sessionStorage.removeItem("admin_auth"); window.location.href = "/admin/login"; }} title="Sign out">
                A
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 md:p-8 animate-fade-in">{children}</div>
      </main>
    </div>
  );
}
