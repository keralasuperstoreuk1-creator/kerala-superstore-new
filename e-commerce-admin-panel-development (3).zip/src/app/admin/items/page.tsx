"use client";

import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, ImageIcon, X } from "lucide-react";

export default function ItemsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({
    name: "", slug: "", description: "", price: "", compareAtPrice: "", sku: "", stock: 0,
    images: [] as string[], categoryId: "", gender: "", ageGroup: "", sortOrder: 0, isActive: true,
  });
  const [variants, setVariants] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const [itemsRes, catRes] = await Promise.all([fetch("/api/items"), fetch("/api/categories")]);
    setItems(await itemsRes.json());
    setCategories(await catRes.json());
  }

  function generateSlug(name: string) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "uploads/items");
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) setForm((f) => ({ ...f, images: [...f.images, data.url] }));
    setUploading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = {
      ...form,
      categoryId: parseInt(form.categoryId),
      price: form.price,
      compareAtPrice: form.compareAtPrice || null,
      slug: form.slug || generateSlug(form.name),
      images: form.images.length > 0 ? form.images : null,
      variants: variants.map((v) => ({ ...v, price: v.price || form.price, stock: parseInt(v.stock) || 0 })),
    };
    if (editing) {
      await fetch("/api/items", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...payload, id: editing.id }) });
    } else {
      await fetch("/api/items", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    }
    setShowForm(false);
    setEditing(null);
    resetForm();
    fetchData();
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this item?")) return;
    await fetch(`/api/items?id=${id}`, { method: "DELETE" });
    fetchData();
  }

  function resetForm() {
    setForm({ name: "", slug: "", description: "", price: "", compareAtPrice: "", sku: "", stock: 0, images: [], categoryId: "", gender: "", ageGroup: "", sortOrder: 0, isActive: true });
    setVariants([]);
  }

  function openEdit(item: any) {
    setEditing(item);
    setForm({
      name: item.name, slug: item.slug, description: item.description || "", price: String(item.price),
      compareAtPrice: item.compareAtPrice ? String(item.compareAtPrice) : "", sku: item.sku || "",
      stock: item.stock || 0, images: item.images || [], categoryId: String(item.categoryId),
      gender: item.gender || "", ageGroup: item.ageGroup || "", sortOrder: item.sortOrder || 0, isActive: item.isActive,
    });
    setVariants(item.variants || []);
    setShowForm(true);
  }

  function addVariant() {
    setVariants([...variants, { color: "", colorCode: "", size: "", price: "", stock: 0, sku: "", images: [] }]);
  }

  function updateVariant(idx: number, field: string, value: any) {
    const v = [...variants];
    v[idx][field] = value;
    setVariants(v);
  }

  function removeVariant(idx: number) {
    setVariants(variants.filter((_, i) => i !== idx));
  }

  async function handleVariantImageUpload(e: React.ChangeEvent<HTMLInputElement>, idx: number) {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder", "uploads/variants");
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) {
      const v = [...variants];
      v[idx].images = [...(v[idx].images || []), data.url];
      setVariants(v);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Items & Products</h1>
        <button onClick={() => { setShowForm(true); setEditing(null); resetForm(); }} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          <Plus className="w-4 h-4" /> Add Item
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 p-6 mb-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
              <select required value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Select Category</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Slug</label>
              <input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} placeholder="Auto-generated" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Price (£)</label>
              <input required type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Compare At Price</label>
              <input type="number" step="0.01" value={form.compareAtPrice} onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Stock</label>
              <input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">SKU</label>
              <input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Gender</label>
              <select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Any</option>
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                <option value="Unisex">Unisex</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Age Group</label>
              <select value={form.ageGroup} onChange={(e) => setForm({ ...form, ageGroup: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Any</option>
                <option value="Baby (0-2)">Baby (0-2)</option>
                <option value="Kids (3-5)">Kids (3-5)</option>
                <option value="Kids (6-12)">Kids (6-12)</option>
                <option value="Teen (13-17)">Teen (13-17)</option>
                <option value="Adult">Adult</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Sort Order</label>
              <input type="number" value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" rows={3} />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Item Images</label>
            <div className="flex items-center gap-3 flex-wrap">
              <label className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                <ImageIcon className="w-4 h-4" />
                <span className="text-sm">{uploading ? "Uploading..." : "Add Image"}</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
              {form.images.map((img, i) => (
                <div key={i} className="relative">
                  <img src={img} alt="" className="w-16 h-16 object-cover rounded-lg" />
                  <button type="button" onClick={() => setForm({ ...form, images: form.images.filter((_, idx) => idx !== i) })} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5"><X className="w-3 h-3" /></button>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-900">Variants (Colors, Sizes)</h3>
              <button type="button" onClick={addVariant} className="flex items-center gap-1 text-sm bg-slate-100 px-3 py-1.5 rounded-lg hover:bg-slate-200"><Plus className="w-3 h-3" /> Add Variant</button>
            </div>
            {variants.map((v, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-6 gap-3 mb-3 p-3 bg-slate-50 rounded-lg">
                <input placeholder="Color" value={v.color} onChange={(e) => updateVariant(idx, "color", e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                <input placeholder="Color Code (#hex)" value={v.colorCode} onChange={(e) => updateVariant(idx, "colorCode", e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                <select value={v.size} onChange={(e) => updateVariant(idx, "size", e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm">
                  <option value="">Size</option>
                  <option value="XS">XS</option>
                  <option value="S">S</option>
                  <option value="M">M</option>
                  <option value="L">L</option>
                  <option value="XL">XL</option>
                  <option value="2XL">2XL</option>
                  <option value="3XL">3XL</option>
                </select>
                <input placeholder="Price (optional)" type="number" step="0.01" value={v.price} onChange={(e) => updateVariant(idx, "price", e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                <input placeholder="Stock" type="number" value={v.stock} onChange={(e) => updateVariant(idx, "stock", e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1 px-2 py-1 border border-slate-300 rounded-lg cursor-pointer hover:bg-white text-xs">
                    <ImageIcon className="w-3 h-3" /> Img
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleVariantImageUpload(e, idx)} />
                  </label>
                  {v.images?.length > 0 && <span className="text-xs text-slate-500">{v.images.length} img</span>}
                  <button type="button" onClick={() => removeVariant(idx)} className="text-red-500 hover:bg-red-50 p-1 rounded"><X className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} className="w-4 h-4" />
            <label className="text-sm text-slate-700">Active</label>
          </div>
          <div className="flex gap-3">
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">{editing ? "Update" : "Create"}</button>
            <button type="button" onClick={() => setShowForm(false)} className="bg-slate-200 text-slate-700 px-6 py-2 rounded-lg hover:bg-slate-300">Cancel</button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Image</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Category</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Price</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Stock</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Variants</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50">
                <td className="px-6 py-4">
                  {item.images?.[0] ? <img src={item.images[0]} alt="" className="w-12 h-12 object-cover rounded-lg" /> : <div className="w-12 h-12 bg-slate-200 rounded-lg" />}
                </td>
                <td className="px-6 py-4 font-medium text-slate-900">{item.name}</td>
                <td className="px-6 py-4 text-slate-500">{categories.find((c) => c.id === item.categoryId)?.name || "-"}</td>
                <td className="px-6 py-4 text-slate-900">£{item.price}</td>
                <td className="px-6 py-4 text-slate-500">{item.stock}</td>
                <td className="px-6 py-4 text-slate-500">{item.variants?.length || 0}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(item.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
