"use client";

import { useEffect, useState } from "react";
import { Eye, CheckCircle, XCircle, Clock } from "lucide-react";

export default function OrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  async function fetchOrders() {
    const res = await fetch("/api/orders");
    const data = await res.json();
    setOrders(data);
  }

  async function updateStatus(id: number, status: string) {
    await fetch("/api/orders", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    fetchOrders();
  }

  async function viewOrder(id: number) {
    const res = await fetch(`/api/orders?id=${id}`);
    const data = await res.json();
    setSelectedOrder(data);
  }

  const statusColors: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    confirmed: "bg-blue-100 text-blue-700",
    shipped: "bg-purple-100 text-purple-700",
    delivered: "bg-emerald-100 text-emerald-700",
    cancelled: "bg-red-100 text-red-700",
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">Orders</h1>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Order #</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Customer</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Phone</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Total</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Date</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {orders.map((o) => (
              <tr key={o.id} className="hover:bg-slate-50">
                <td className="px-6 py-4 font-medium text-slate-900">{o.orderNumber}</td>
                <td className="px-6 py-4 text-slate-700">{o.customerName}</td>
                <td className="px-6 py-4 text-slate-500">{o.customerPhone}</td>
                <td className="px-6 py-4 font-medium text-slate-900">£{parseFloat(o.totalAmount).toFixed(2)}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[o.status] || "bg-slate-100 text-slate-600"}`}>
                    {o.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-500 text-sm">{o.createdAt ? new Date(o.createdAt).toLocaleDateString() : "-"}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button onClick={() => viewOrder(o.id)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"><Eye className="w-4 h-4" /></button>
                    {o.status === "pending" && (
                      <button onClick={() => updateStatus(o.id, "confirmed")} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg" title="Confirm"><CheckCircle className="w-4 h-4" /></button>
                    )}
                    {o.status !== "cancelled" && o.status !== "delivered" && (
                      <button onClick={() => updateStatus(o.id, "cancelled")} className="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="Cancel"><XCircle className="w-4 h-4" /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-slate-900">Order {selectedOrder.orderNumber}</h2>
              <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-slate-100 rounded-lg"><XCircle className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm text-slate-500">Customer</p>
                  <p className="font-medium text-slate-900">{selectedOrder.customerName}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm text-slate-500">Phone</p>
                  <p className="font-medium text-slate-900">{selectedOrder.customerPhone}</p>
                </div>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500">Address</p>
                <p className="font-medium text-slate-900">{selectedOrder.address}</p>
                <p className="text-slate-700">{selectedOrder.city} {selectedOrder.postcode}</p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">Items</h3>
                <div className="space-y-2">
                  {selectedOrder.items?.map((item: any) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div>
                        <p className="font-medium text-slate-900">{item.itemName}</p>
                        {item.variantName && <p className="text-sm text-slate-500">{item.variantName}</p>}
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-slate-500">x{item.quantity}</p>
                        <p className="font-medium text-slate-900">£{parseFloat(item.total).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <p className="text-slate-500">Payment: <span className="font-medium text-slate-900">{selectedOrder.paymentMethod?.toUpperCase()}</span></p>
                <p className="text-xl font-bold text-slate-900">Total: £{parseFloat(selectedOrder.totalAmount).toFixed(2)}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
