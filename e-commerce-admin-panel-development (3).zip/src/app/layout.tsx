import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kerala Super Store - UK | South Indian Grocery Online",
  description: "Kerala Super Store - Your trusted South Indian grocery store in the UK. Fresh products delivered to your doorstep.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-white text-slate-900 antialiased">{children}</body>
    </html>
  );
}
